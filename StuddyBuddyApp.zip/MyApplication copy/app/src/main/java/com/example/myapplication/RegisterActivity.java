package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private Button register;
    private EditText mail, password, passwordConfirm, userName;

    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener firebaseAuthSL;
    private String mailPattern = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";
    private static final String Tag = "RegisterActivity";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth = FirebaseAuth.getInstance();
        firebaseAuthSL = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if(user != null && user.isEmailVerified()){
                    Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(i);
                    finish();
                    return;
                }
            }
        };
    register = (Button) findViewById(R.id.register);
    mail = (EditText) findViewById(R.id.mail);
    password = (EditText) findViewById(R.id.password);
    passwordConfirm = (EditText) findViewById(R.id.passwordConfirm);
    userName = (EditText) findViewById(R.id.userName);

    register.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final String email = mail.getText().toString();
            final String pass = password.getText().toString();
            final String passConf = passwordConfirm.getText().toString();
            final String uName = userName.getText().toString();

            if(checkInputs(email,pass,uName)){
                auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isSuccessful()) {
                            Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }else{
                            auth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(RegisterActivity.this, "Registration Successful!" + "Check Email for Verification.", Toast.LENGTH_SHORT).show();
                                        String userId = auth.getCurrentUser().getUid();
                                        DatabaseReference currentUserDb = FirebaseDatabase.getInstance().getReference().child("Users").child(userId);

                                        Map userInfo = new HashMap<>();
                                        userInfo.put("name", uName);
                                        userInfo.put("profileImageUrl", "default");
                                        currentUserDb.updateChildren(userInfo);

                                        mail.setText("");
                                        userName.setText("");
                                        password.setText("");
                                        Intent i = new Intent(RegisterActivity.this, Choose_Login_Register.class);
                                        startActivity(i);
                                        finish();
                                        return;
                                    }
                                    Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });
            }
        }
    });
    }
    private boolean checkInputs(String email, String pass, String uName){
        if(email.equals("") || uName.equals("") || pass.equals("")){
            Toast.makeText(this, "You must fill out all fields! Please check your information", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!email.matches(mailPattern)){
            Toast.makeText(this, "Invalid email address, please enter valid email and try again.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        auth.addAuthStateListener(firebaseAuthSL);
    }

    @Override
    protected void onStop() {
        super.onStop();
        auth.removeAuthStateListener(firebaseAuthSL);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(RegisterActivity.this, Choose_Login_Register.class);
        startActivity(i);
        finish();
    }
}
package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";

    private Button login;
    private EditText mail;
    private EditText password;
    private boolean loginClicked;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener firebaseSL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        loginClicked = false;
        auth = FirebaseAuth.getInstance();
        login = (Button) findViewById(R.id.login);
        password = (EditText) findViewById(R.id.password);
        mail = (EditText) findViewById(R.id.mail);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginClicked = true;
                final String email = mail.getText().toString();
                final String pass = password.getText().toString();

                if(isStringNull(email) || isStringNull(pass)){
                    Toast.makeText(LoginActivity.this, "You must fill out all fields!", Toast.LENGTH_SHORT).show();
                } else {
                    auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(LoginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }else{
                                if(Objects.requireNonNull(auth.getCurrentUser()).isEmailVerified()){
                                    Intent i = new Intent(LoginActivity.this, MainActivity.class);
                                    startActivity(i);
                                    finish();

                                }else{
                                    Toast.makeText(LoginActivity.this, "Please verify your e-mail.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });
                }
            }
        });
        firebaseSL = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if(user != null && user.isEmailVerified() && !loginClicked){
                    Intent i = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        };
    }
    private boolean isStringNull(String mail){
        return mail.equals("");
    }
    @Override
    protected void onStart(){
        super.onStart();
        auth.addAuthStateListener(firebaseSL);
    }

    @Override
    protected void onStop() {
        super.onStop();
        auth.addAuthStateListener(firebaseSL);
    }

    @Override
    public void onBackPressed(){
        Intent i = new Intent(LoginActivity.this, Choose_Login_Register.class);
        startActivity(i);
        finish();
        return;
    }
}
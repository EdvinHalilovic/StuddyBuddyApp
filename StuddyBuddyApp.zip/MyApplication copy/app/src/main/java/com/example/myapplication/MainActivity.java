package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button calculus, chemistry, programming, art;
    private AppCompatButton account, chat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calculus = (Button) findViewById(R.id.calculus);
        chemistry = (Button) findViewById(R.id.chemistry);
        programming = (Button) findViewById(R.id.programming);
        art = (Button) findViewById(R.id.art);
        account = (AppCompatButton) findViewById(R.id.account);
        chat = (AppCompatButton) findViewById(R.id.chat);

        calculus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SwipeActivity.class);
                startActivity(i);
                finish();
                return;
            }
        });

        chemistry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SwipeActivity.class);
                startActivity(i);
                finish();
                return;
            }
        });

        programming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SwipeActivity.class);
                startActivity(i);
                finish();
                return;
            }
        });

        art.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SwipeActivity.class);
                startActivity(i);
                finish();
                return;
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AccountActivity.class);
                startActivity(i);
                finish();
            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ChatActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed(){
        Intent i = new Intent(MainActivity.this, SwipeActivity.class);
        startActivity(i);
        finish();
        return;
    }
}